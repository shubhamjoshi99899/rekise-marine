import React from "react";
import MapComponent from "./components/MapComponent.tsx";

const App = () => {
  return (
    <div>
      <MapComponent />
    </div>
  );
};

export default App;
