import React from "react";
import Modal from "react-modal";

const PolygonModal = ({ waypoints, onClose }) => {
  return (
    <Modal isOpen={true} onRequestClose={onClose}>
      <h2>Polygon Waypoints</h2>
      <ul>
        {waypoints.map((wp, index) => (
          <li key={index}>
            WP{index.toString().padStart(2, "0")}: {wp.join(", ")}
          </li>
        ))}
      </ul>
      <button onClick={onClose}>Close</button>
    </Modal>
  );
};

export default PolygonModal;
