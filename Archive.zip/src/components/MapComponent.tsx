import React, { useEffect, useRef, useState } from "react";
import {
  Box,
  AppBar,
  Toolbar,
  Typography,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Checkbox,
  IconButton,
  Menu,
  MenuItem as DropdownMenuItem,
} from "@mui/material";
import "ol/ol.css";
import Draw from "ol/interaction/Draw";
import Map from "ol/Map";
import VectorLayer from "ol/layer/Vector";
import VectorSource from "ol/source/Vector";
import View from "ol/View";
import XYZ from "ol/source/XYZ";
import { fromLonLat, transform } from "ol/proj";
import { LineString, Polygon } from "ol/geom";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import TileLayer from "ol/layer/Tile";

const MapComponent: React.FC = () => {
  const mapRef = useRef<HTMLDivElement | null>(null);
  const [map, setMap] = useState<Map | null>(null);
  const [drawInteraction, setDrawInteraction] = useState<Draw | null>(null);
  const [coordinates, setCoordinates] = useState<any[]>([]);
  const [polygonCoordinates, setPolygonCoordinates] = useState<number[][]>([]);
  const [dropdownAnchorEl, setDropdownAnchorEl] = useState<null | HTMLElement>(
    null
  );
  const [dropdownRowIndex, setDropdownRowIndex] = useState<number | null>(null);
  const [viewMode, setViewMode] = useState<string>("LineString");
  const [collapsedRows, setCollapsedRows] = useState<{
    [key: string]: boolean;
  }>({});
  const openDropdown = Boolean(dropdownAnchorEl);

  useEffect(() => {
    const raster = new TileLayer({
      source: new XYZ({
        url: "https://api.maptiler.com/maps/satellite/{z}/{x}/{y}.jpg?key=get_your_own_D6rA4zTHduk6KOKTXzGB",
        maxZoom: 20,
      }),
    });

    const drawVector = new VectorLayer({
      source: new VectorSource(),
    });

    const initialMap = new Map({
      target: mapRef.current || undefined,
      layers: [raster, drawVector],
      view: new View({
        center: fromLonLat([82.9726, 22.5937]),
        zoom: 5,
      }),
    });

    setMap(initialMap);

    return () => {
      initialMap.setTarget(undefined);
    };
  }, []);

  const calculateDistance = (coord1: number[], coord2: number[]) => {
    if (
      !Array.isArray(coord1) ||
      !Array.isArray(coord2) ||
      coord1.length !== 2 ||
      coord2.length !== 2
    ) {
      console.error(
        "Invalid coordinates passed to calculateDistance:",
        coord1,
        coord2
      );
      return 0; // Return 0 if invalid
    }

    const toRad = (value: number) => (value * Math.PI) / 180;
    const R = 6371000;
    const [lon1, lat1] = coord1;
    const [lon2, lat2] = coord2;

    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(toRad(lat1)) *
        Math.cos(toRad(lat2)) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const startLineStringDrawing = () => {
    if (map) {
      const drawLayer = map.getLayers().getArray()[1] as VectorLayer;
      const drawSource = drawLayer.getSource() as VectorSource;

      const draw = new Draw({
        type: "LineString",
        source: drawSource,
      });

      draw.on("drawstart", () => {
        setCoordinates([]); // Reset coordinates when a new drawing starts
      });

      draw.on("drawend", (event) => {
        const geometry = event.feature.getGeometry() as LineString; // Cast to LineString
        const coords = geometry.getCoordinates(); // Now getCoordinates works
        const transformedCoords = coords.map((coord) =>
          transform(coord, "EPSG:3857", "EPSG:4326")
        );
        setCoordinates(transformedCoords);
      });
      map.addInteraction(draw);
      setDrawInteraction(draw);
    }
  };

  const startPolygonDrawing = () => {
    console.log(coordinates);

    if (map) {
      const drawLayer = map.getLayers().getArray()[1] as VectorLayer;
      const drawSource = drawLayer.getSource() as VectorSource;

      const draw = new Draw({
        type: "Polygon",
        source: drawSource,
      });

      draw.on("drawstart", () => {
        setPolygonCoordinates([]); // Reset polygon coordinates
      });

      //   draw.on("change", (event) => {
      //     const geometry = event.target.getGeometry() as Polygon; // Cast to Polygon
      //     const coords = geometry.getCoordinates()[0]; // Get the outer ring
      //     const transformedCoords = coords.map((coord) =>
      //       transform(coord, "EPSG:3857", "EPSG:4326")
      //     );
      //     setPolygonCoordinates(transformedCoords);
      //   });

      draw.on("drawend", (event) => {
        const geometry = event.feature.getGeometry() as Polygon; // Cast to Polygon
        const coords = geometry.getCoordinates()[0]; // Get the outer ring
        const transformedCoords = coords.map((coord) =>
          transform(coord, "EPSG:3857", "EPSG:4326")
        );
        setPolygonCoordinates(transformedCoords);
        set;
      });

      map.addInteraction(draw);
      setDrawInteraction(draw);
    }
    console.log(polygonCoordinates);
  };

  const handleDropdownClick = (
    event: React.MouseEvent<HTMLElement>,
    index: number
  ) => {
    setDropdownAnchorEl(event.currentTarget);
    setDropdownRowIndex(index);
  };

  const handleDropdownClose = () => {
    setDropdownAnchorEl(null);
  };

  const handleInsertPolygon = (type: "before" | "after") => {
    startPolygonDrawing();
    setViewMode("Polygon");
    handleDropdownClose();
  };

  const handleImportPolygon = (type: "before" | "after") => {
    console.log("coordinates", coordinates);
    console.log("polygonCoordinates", polygonCoordinates);

    if (polygonCoordinates.length > 0 && dropdownRowIndex !== null) {
      const updatedCoordinates = [...coordinates];
      const polygonEntry = {
        label: `Polygon ${Object.keys(collapsedRows).length + 1}`,
        points: polygonCoordinates,
      };

      if (type === "before") {
        updatedCoordinates.splice(dropdownRowIndex, 0, polygonEntry);
      } else if (type === "after") {
        updatedCoordinates.splice(dropdownRowIndex + 1, 0, polygonEntry);
      }

      setCoordinates(updatedCoordinates);
      setCollapsedRows((prev) => ({
        ...prev,
        [`Polygon ${Object.keys(collapsedRows).length + 1}`]: true, // Default expanded
      }));
      setPolygonCoordinates([]); // Reset polygon coordinates
      setViewMode("LineString");
    }
  };

  const toggleCollapse = (label: string) => {
    setCollapsedRows((prev) => ({
      ...prev,
      [label]: !prev[label],
    }));
  };

  const getLineStringData = () => {
    return coordinates.flatMap((entry, index) => {
      if (typeof entry === "object" && entry.label) {
        const rows = [
          {
            index: index.toString().padStart(2, "0"),
            label: entry.label,
            latitude: "Polygon",
            longitude: "",
            distance: "--",
            isPolygon: true,
          },
        ];

        if (collapsedRows[entry.label]) {
          let totalDistance = 0;
          const expandedRows = entry.points.map(
            (point: number[], subIndex: number) => {
              let distance = "--";
              if (subIndex > 0) {
                distance = calculateDistance(
                  entry.points[subIndex - 1],
                  point
                ).toFixed(2);
                totalDistance += parseFloat(distance);
              }
              return {
                index: `${index}-${subIndex + 1}`,
                latitude: point[1].toFixed(5),
                longitude: point[0].toFixed(5),
                distance,
                isPolygon: false,
              };
            }
          );

          return rows.concat(expandedRows);
        }

        return rows;
      } else {
        let distance = "--";
        if (index > 0) {
          distance = calculateDistance(coordinates[index - 1], entry).toFixed(
            2
          );
        }
        return [
          {
            index: index.toString().padStart(2, "0"),
            latitude: entry[1].toFixed(5),
            longitude: entry[0].toFixed(5),
            distance,
            isPolygon: false,
          },
        ];
      }
    });
  };

  return (
    <Box>
      <AppBar position="static" sx={{ backgroundColor: "#fff" }}>
        <Toolbar>
          <Typography variant="h6" sx={{ flexGrow: 1, color: "#000" }}>
            Map Drawing App
          </Typography>
          <Button
            color="primary"
            variant="contained"
            onClick={startLineStringDrawing}
          >
            Draw
          </Button>
        </Toolbar>
      </AppBar>

      <Box
        ref={mapRef}
        sx={{
          width: "100%",
          height: "800px",
          border: "1px solid #ccc",
          marginTop: "16px",
        }}
      ></Box>

      {viewMode === "Polygon" && (
        <Box
          sx={{
            position: "absolute",
            top: "10%",
            right: "10%",
            width: 500,
            bgcolor: "background.paper",
            boxShadow: 24,
            p: 4,
          }}
        >
          <Typography variant="h6" sx={{ marginBottom: "8px" }}>
            Polygon Tool
          </Typography>
          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>WP</TableCell>
                  <TableCell>Coordinates</TableCell>
                  <TableCell>Distance (m)</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {polygonCoordinates.map((coord, index) => {
                  let distance = "--";
                  if (
                    index > 0 &&
                    Array.isArray(polygonCoordinates[index - 1]) &&
                    Array.isArray(coord)
                  ) {
                    distance = calculateDistance(
                      polygonCoordinates[index - 1],
                      coord
                    ).toFixed(2);
                  }
                  return (
                    <TableRow key={index}>
                      <TableCell>{index + 1}</TableCell>
                      <TableCell>
                        {coord[1]?.toFixed(5) || "N/A"},{" "}
                        {coord[0]?.toFixed(5) || "N/A"}
                      </TableCell>
                      <TableCell>{distance}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
          <Box>
            <Button
              color="primary"
              variant="contained"
              sx={{ marginTop: "16px" }}
              onClick={() => handleImportPolygon("after")}
            >
              Import Points
            </Button>
          </Box>
        </Box>
      )}

      {viewMode === "LineString" && (
        <Box
          sx={{
            position: "absolute",
            top: "10%",
            right: "10%",
            width: 500,
            bgcolor: "background.paper",
            boxShadow: 24,
            p: 4,
          }}
        >
          <Typography variant="h6" sx={{ marginBottom: "8px" }}>
            Mission Creation
          </Typography>
          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>WP</TableCell>
                  <TableCell>Coordinates</TableCell>
                  <TableCell>Distance (m)</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {getLineStringData().map((row: any, index) => (
                  <TableRow key={index}>
                    <TableCell>
                      <Checkbox />
                      {row.index}
                    </TableCell>
                    <TableCell>
                      {row.isPolygon ? (
                        <Button onClick={() => toggleCollapse(row.label)}>
                          {row.label} {collapsedRows[row.label] ? "▼" : "▶"}
                        </Button>
                      ) : (
                        `${row.latitude}, ${row.longitude}`
                      )}
                    </TableCell>
                    <TableCell>{row.distance}</TableCell>
                    {!row.isPolygon && (
                      <TableCell>
                        <IconButton
                          onClick={(event) => handleDropdownClick(event, index)}
                        >
                          <MoreVertIcon />
                        </IconButton>
                      </TableCell>
                    )}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          <Menu
            anchorEl={dropdownAnchorEl}
            open={openDropdown}
            onClose={handleDropdownClose}
          >
            <DropdownMenuItem onClick={() => handleInsertPolygon("before")}>
              Insert Polygon Before
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleInsertPolygon("after")}>
              Insert Polygon After
            </DropdownMenuItem>
          </Menu>
        </Box>
      )}
    </Box>
  );
};

export default MapComponent;
