import React, { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Collapse,
  Typography,
  Checkbox,
  Box,
  Button,
} from "@mui/material";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";

const MissionTable = ({ coordinates, polygonCoordinates, insertPolygon }) => {
  const [openRows, setOpenRows] = useState<number[]>([]);

  const toggleRow = (index: number) => {
    setOpenRows((prev) =>
      prev.includes(index) ? prev.filter((i) => i !== index) : [...prev, index]
    );
  };
  const calculateDistance = (coord1: number[], coord2: number[]) => {
    const toRad = (value: number) => (value * Math.PI) / 180;
    const R = 6371000;
    const [lon1, lat1] = coord1;
    const [lon2, lat2] = coord2;

    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(toRad(lat1)) *
        Math.cos(toRad(lat2)) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };
  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell />
            <TableCell>WP</TableCell>
            <TableCell>Coordinates</TableCell>
            <TableCell>Distance (m)</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {coordinates.map((row, index) => (
            <React.Fragment key={index}>
              <TableRow>
                <TableCell>
                  <IconButton onClick={() => toggleRow(index)}>
                    {openRows.includes(index) ? (
                      <KeyboardArrowUpIcon />
                    ) : (
                      <KeyboardArrowDownIcon />
                    )}
                  </IconButton>
                </TableCell>
                <TableCell>
                  <Checkbox />
                  {index.toString().padStart(2, "0")}
                </TableCell>
                <TableCell>
                  {row[1].toFixed(5)}, {row[0].toFixed(5)}
                </TableCell>
                <TableCell>
                  {index > 0
                    ? calculateDistance(coordinates[index - 1], row).toFixed(2)
                    : "--"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  style={{ paddingBottom: 0, paddingTop: 0 }}
                  colSpan={4}
                >
                  <Collapse
                    in={openRows.includes(index)}
                    timeout="auto"
                    unmountOnExit
                  >
                    <Box margin={1}>
                      <Typography variant="h6" gutterBottom component="div">
                        Polygon Coordinates
                      </Typography>
                      <Table size="small">
                        <TableHead>
                          <TableRow>
                            <TableCell>WP</TableCell>
                            <TableCell>Coordinates</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {polygonCoordinates.map((coord, polyIndex) => (
                            <TableRow key={polyIndex}>
                              <TableCell>
                                <Checkbox />
                                {polyIndex.toString().padStart(2, "0")}
                              </TableCell>
                              <TableCell>
                                {coord[1].toFixed(5)}, {coord[0].toFixed(5)}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                      <Button
                        variant="contained"
                        onClick={() => insertPolygon("before", index)}
                        style={{ marginRight: "8px" }}
                      >
                        Add Polygon Before
                      </Button>
                      <Button
                        variant="contained"
                        onClick={() => insertPolygon("after", index)}
                      >
                        Add Polygon After
                      </Button>
                    </Box>
                  </Collapse>
                </TableCell>
              </TableRow>
            </React.Fragment>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default MissionTable;
