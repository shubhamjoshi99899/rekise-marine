import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  List,
  ListItem,
  ListItemText,
} from "@mui/material";

interface ModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  data: Array<{ wp: string; coords: [number, number]; distance: number }>;
}

const ModalComponent: React.FC<ModalProps> = ({
  open,
  onClose,
  title,
  data,
}) => {
  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="sm">
      <DialogTitle>{title}</DialogTitle>
      <DialogContent>
        <List>
          {data.map((item, index) => (
            <ListItem key={index}>
              <ListItemText
                primary={`WP(${item.wp}): (${item.coords[0]}, ${item.coords[1]})`}
                secondary={`Distance: ${item.distance.toFixed(2)} meters`}
              />
            </ListItem>
          ))}
        </List>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
};

export default ModalComponent;
