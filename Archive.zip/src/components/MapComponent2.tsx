import React, { useEffect, useRef, useState } from "react";
import {
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Box,
  AppBar,
  Toolbar,
  Typography,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Checkbox,
  IconButton,
  Menu,
  MenuItem as DropdownMenuItem,
} from "@mui/material";
import "ol/ol.css";
import Draw from "ol/interaction/Draw";
import Map from "ol/Map";
import Snap from "ol/interaction/Snap";
import TileLayer from "ol/layer/Tile";
import VectorLayer from "ol/layer/Vector";
import VectorSource from "ol/source/Vector";
import View from "ol/View";
import XYZ from "ol/source/XYZ";
import MoreVertIcon from "@mui/icons-material/MoreVert";

const MapComponent: React.FC = () => {
  const mapRef = useRef<HTMLDivElement | null>(null);
  const [map, setMap] = useState<Map | null>(null);
  const [drawInteraction, setDrawInteraction] = useState<Draw | null>(null);
  const [selectedType, setSelectedType] = useState<string>("None");
  const [coordinates, setCoordinates] = useState<number[][]>([]);
  const [dropdownAnchorEl, setDropdownAnchorEl] = useState<null | HTMLElement>(
    null
  );
  const [polygonMode, setPolygonMode] = useState<boolean>(false);
  const [dropdownRowIndex, setDropdownRowIndex] = useState<number | null>(null);

  const openDropdown = Boolean(dropdownAnchorEl);

  useEffect(() => {
    const raster = new TileLayer({
      source: new XYZ({
        url: "https://api.maptiler.com/maps/satellite/{z}/{x}/{y}.jpg?key=get_your_own_D6rA4zTHduk6KOKTXzGB",
        maxZoom: 20,
      }),
    });

    const drawVector = new VectorLayer({
      source: new VectorSource(),
    });

    const initialMap = new Map({
      target: mapRef.current || undefined,
      layers: [raster, drawVector],
      view: new View({
        center: [-13378949, 5943751],
        zoom: 11,
      }),
    });

    setMap(initialMap);

    return () => {
      initialMap.setTarget(undefined);
    };
  }, []);

  useEffect(() => {
    if (map) {
      const drawLayer = map.getLayers().getArray()[1] as VectorLayer;
      const drawSource = drawLayer.getSource() as VectorSource;

      const updateInteraction = (type: string) => {
        if (drawInteraction) {
          map.removeInteraction(drawInteraction);
        }

        if (type === "Polygon") {
          const draw = new Draw({
            type: "Polygon",
            source: drawSource,
          });

          draw.on("drawstart", () => {
            setCoordinates([]); // Reset coordinates
          });

          draw.on("drawend", (event) => {
            const geometry = event.feature.getGeometry();
            if (geometry) {
              setCoordinates((geometry as any).getCoordinates());
            }
          });

          map.addInteraction(draw);
          setDrawInteraction(draw);
        }
      };

      updateInteraction(selectedType);

      return () => {
        if (drawInteraction) {
          map.removeInteraction(drawInteraction);
        }
      };
    }
  }, [map, selectedType]);

  const handleDropdownClick = (
    event: React.MouseEvent<HTMLElement>,
    index: number
  ) => {
    setDropdownAnchorEl(event.currentTarget);
    setDropdownRowIndex(index);
  };

  const handleDropdownClose = () => {
    setDropdownAnchorEl(null);
    setDropdownRowIndex(null);
  };

  const handleInsertPolygon = (type: "before" | "after") => {
    setPolygonMode(true);
    setSelectedType("Polygon");
    handleDropdownClose();
  };

  const getTableData = () => {
    let totalDistance = 0;
    return coordinates.map((coord, index) => {
      const distance =
        index > 0 ? calculateDistance(coordinates[index - 1], coord) : 0;
      totalDistance += distance;
      return {
        index: index.toString().padStart(2, "0"),
        latitude: coord[1],
        longitude: coord[0],
        distance: index > 0 ? distance.toFixed(2) : "--",
      };
    });
  };

  const calculateDistance = (coord1: number[], coord2: number[]) => {
    const toRad = (value: number) => (value * Math.PI) / 180;
    const R = 6371000; // Earth's radius in meters
    const [lon1, lat1] = coord1;
    const [lon2, lat2] = coord2;

    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(toRad(lat1)) *
        Math.cos(toRad(lat2)) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  return (
    <Box>
      <AppBar position="static" sx={{ backgroundColor: "#fff" }}>
        <Toolbar>
          <Typography variant="h6" sx={{ flexGrow: 1, color: "#000" }}>
            Map Drawing App
          </Typography>
        </Toolbar>
      </AppBar>
      <Box ref={mapRef} sx={{ width: "100%", height: "800px" }}></Box>
      <TableContainer component={Paper} sx={{ marginTop: "16px" }}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>WP</TableCell>
              <TableCell>Coordinates</TableCell>
              <TableCell>Distance (m)</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {getTableData().map((row, index) => (
              <TableRow key={index}>
                <TableCell>
                  <Checkbox />
                  {row.index}
                </TableCell>
                <TableCell>
                  {row.latitude.toFixed(3)}, {row.longitude.toFixed(3)}
                </TableCell>
                <TableCell>{row.distance}</TableCell>
                <TableCell>
                  <IconButton
                    onClick={(event) => handleDropdownClick(event, index)}
                  >
                    <MoreVertIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Menu
        anchorEl={dropdownAnchorEl}
        open={openDropdown}
        onClose={handleDropdownClose}
      >
        <DropdownMenuItem onClick={() => handleInsertPolygon("before")}>
          Insert Polygon Before
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleInsertPolygon("after")}>
          Insert Polygon After
        </DropdownMenuItem>
      </Menu>
    </Box>
  );
};

export default MapComponent;
